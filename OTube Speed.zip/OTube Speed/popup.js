document.addEventListener('DOMContentLoaded', function() {
    const speedButtons = document.querySelectorAll('.speed-button');
    const customSpeedInput = document.getElementById('customSpeed');
    const setCustomButton = document.getElementById('setCustom');
    const setFavoriteButton = document.getElementById('setFavorite');
    const statusDiv = document.getElementById('status');
    const favoriteSpeedDisplay = document.querySelector('.favorite-speed');
    let currentSpeed = 1;

    // Check current video speed when popup opens
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0].url.includes('youtube.com')) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: "getSpeed"
            }, function(response) {
                if (response && response.success) {
                    currentSpeed = response.speed;
                    updateActiveButton(currentSpeed);
                    customSpeedInput.value = currentSpeed;
                }
            });
        }
    });

    // Load and display favorite speed
    function updateFavoriteSpeedDisplay(speed) {
        if (speed) {
            favoriteSpeedDisplay.textContent = speed + 'x';
            favoriteSpeedDisplay.style.opacity = '1';
            favoriteSpeedDisplay.parentElement.style.opacity = '1';
        } else {
            favoriteSpeedDisplay.textContent = 'Not set';
            favoriteSpeedDisplay.style.opacity = '0.7';
            favoriteSpeedDisplay.parentElement.style.opacity = '0.7';
        }
    }

    // Load favorite speed
    chrome.storage.local.get(['favoriteSpeed'], function(result) {
        if (result.favoriteSpeed) {
            customSpeedInput.value = result.favoriteSpeed;
            updateFavoriteSpeedDisplay(result.favoriteSpeed);
        }
    });

    // Function to update video speed
    function setVideoSpeed(speed) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0].url.includes('youtube.com')) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: "setSpeed",
                    speed: speed
                }, function(response) {
                    if (response && response.success) {
                        currentSpeed = speed;
                        updateStatus(`Speed set to ${speed}x`, 'success');
                        updateActiveButton(speed);
                        customSpeedInput.value = speed;
                    } else {
                        updateStatus('No video found', 'error');
                    }
                });
            } else {
                updateStatus('Not a YouTube page', 'error');
            }
        });
    }

    // Update status message with animation
    function updateStatus(message, type = 'info') {
        statusDiv.textContent = message;
        statusDiv.className = 'status show';
        
        // Add color based on type
        statusDiv.style.backgroundColor = type === 'error' ? '#fce8e8' : 
                                        type === 'success' ? '#e6f4ea' : 
                                        '#f8f9fa';
        statusDiv.style.color = type === 'error' ? '#c5221f' : 
                               type === 'success' ? '#137333' : 
                               '#5f6368';

        setTimeout(() => {
            statusDiv.className = 'status';
        }, 2000);
    }

    // Update active button state with smooth transition
    function updateActiveButton(speed) {
        speedButtons.forEach(button => {
            const buttonSpeed = parseFloat(button.dataset.speed);
            if (Math.abs(buttonSpeed - speed) < 0.01) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });
    }

    // Event listeners for preset speed buttons
    speedButtons.forEach(button => {
        button.addEventListener('click', function() {
            const speed = parseFloat(this.dataset.speed);
            setVideoSpeed(speed);
        });
    });

    // Event listener for custom speed input
    customSpeedInput.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9.]/g, '');
    });

    // Event listener for custom speed button
    setCustomButton.addEventListener('click', function() {
        const speed = parseFloat(customSpeedInput.value);
        if (speed >= 0.1 && speed <= 16) {
            setVideoSpeed(speed);
        } else {
            updateStatus('Speed must be between 0.1 and 16', 'error');
        }
    });

    // Event listener for set favorite button
    setFavoriteButton.addEventListener('click', function() {
        const speed = currentSpeed;
        chrome.storage.local.set({
            favoriteSpeed: speed
        }, function() {
            updateStatus('Favorite speed saved!', 'success');
            updateFavoriteSpeedDisplay(speed);
            
            // Add animation to favorite button
            const icon = setFavoriteButton.querySelector('.material-symbols-rounded');
            icon.style.transform = 'scale(1.2)';
            setTimeout(() => {
                icon.style.transform = 'scale(1)';
            }, 200);
        });
    });

    // Enter key support for custom speed input
    customSpeedInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            setCustomButton.click();
        }
    });
});
