# Browser Extension

This is a basic browser extension that works with Chrome and Brave browsers.

## Installation Instructions

1. Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" in the top right corner
   - Click "Load unpacked" and select this extension directory

2. Brave:
   - Open Brave and go to `brave://extensions/`
   - Enable "Developer mode" in the top right corner
   - Click "Load unpacked" and select this extension directory

## Features
- Basic popup interface
- Example button click functionality
- Works on both Chrome and Brave browsers

## Structure
- `manifest.json`: Extension configuration
- `popup.html`: Extension popup interface
- `popup.js`: Extension functionality
- `icons/`: Directory containing extension icons

## Development
To modify the extension:
1. Edit the files as needed
2. Go to the extensions page in your browser
3. Click the refresh icon on your extension card
4. Your changes will be reflected immediately

## Note
You'll need to add your own icon files in the `icons` directory:
- icon16.png (16x16)
- icon48.png (48x48)
- icon128.png (128x128)
