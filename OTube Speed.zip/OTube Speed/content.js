// Wrap everything in a try-catch to handle extension context invalidation
try {
    // Function to initialize all listeners and observers
    function initializeExtension() {
        // Listen for messages from the popup
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            try {
                const video = document.querySelector('video');
                
                if (request.action === "setSpeed") {
                    if (video) {
                        // Check if this is a live stream
                        const isLive = document.querySelector('.ytp-live') !== null;
                        
                        if (isLive) {
                            // For live streams, only allow speed changes if there's a delay
                            const liveDelay = video.duration - video.currentTime;
                            if (liveDelay < 10) { // If less than 10 seconds behind live
                                video.playbackRate = 1.0; // Force normal speed
                                sendResponse({ success: false, error: "Cannot change speed of live stream without delay" });
                                return true;
                            }
                        }
                        
                        video.playbackRate = request.speed;
                        sendResponse({ success: true });
                    } else {
                        sendResponse({ success: false, error: "No Video Found" });
                    }
                } else if (request.action === "getSpeed") {
                    if (video) {
                        sendResponse({ success: true, speed: video.playbackRate });
                    } else {
                        sendResponse({ success: false, error: "No Video Found" });
                    }
                }
                return true;
            } catch (error) {
                console.error('Error in message listener:', error);
                sendResponse({ success: false, error: "Extension error occurred" });
                return true;
            }
        });

        // Track current video and its URL
        let currentVideoUrl = '';
        let currentVideo = null;
        let liveCheckInterval = null;

        // Function to check if video is live and handle speed accordingly
        function handleVideoSpeed(video, targetSpeed) {
            try {
                const isLive = document.querySelector('.ytp-live') !== null;
                
                if (isLive) {
                    const liveDelay = video.duration - video.currentTime;
                    if (liveDelay < 10) { // If less than 10 seconds behind live
                        video.playbackRate = 1.0; // Force normal speed
                        return;
                    }
                }
                
                video.playbackRate = targetSpeed;
            } catch (error) {
                console.error('Error in handleVideoSpeed:', error);
            }
        }

        // Function to apply favorite speed to video
        function applyFavoriteSpeed(video) {
            if (!video) return;
            
            try {
                chrome.storage.local.get(['favoriteSpeed'], function(result) {
                    if (chrome.runtime.lastError) {
                        console.error('Storage error:', chrome.runtime.lastError);
                        return;
                    }
                    if (result.favoriteSpeed) {
                        handleVideoSpeed(video, result.favoriteSpeed);
                    }
                });
            } catch (error) {
                console.error('Error in applyFavoriteSpeed:', error);
            }
        }

        // Function to check for new video
        function checkForNewVideo() {
            try {
                const video = document.querySelector('video');
                const videoUrl = window.location.href;
                
                // If we found a video element
                if (video) {
                    // If it's a new video element or URL changed
                    if (video !== currentVideo || videoUrl !== currentVideoUrl) {
                        // Clear existing interval if any
                        if (liveCheckInterval) {
                            clearInterval(liveCheckInterval);
                            liveCheckInterval = null;
                        }

                        currentVideo = video;
                        currentVideoUrl = videoUrl;
                        applyFavoriteSpeed(video);
                        
                        // Also watch for video source changes
                        video.addEventListener('loadeddata', () => {
                            applyFavoriteSpeed(video);
                        });
                        
                        // For live streams, check delay periodically
                        if (document.querySelector('.ytp-live') !== null) {
                            liveCheckInterval = setInterval(() => {
                                chrome.storage.local.get(['favoriteSpeed'], function(result) {
                                    if (chrome.runtime.lastError) {
                                        clearInterval(liveCheckInterval);
                                        return;
                                    }
                                    if (result.favoriteSpeed) {
                                        handleVideoSpeed(video, result.favoriteSpeed);
                                    }
                                });
                            }, 5000); // Check every 5 seconds
                        }
                    }
                }
            } catch (error) {
                console.error('Error in checkForNewVideo:', error);
            }
        }

        // Set up observers
        const observer = new MutationObserver(checkForNewVideo);

        // Observe both body and head for changes
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        // Initial check
        checkForNewVideo();

        // Listen for storage changes to update speed immediately
        chrome.storage.onChanged.addListener((changes, namespace) => {
            try {
                if (namespace === 'local' && changes.favoriteSpeed) {
                    const video = document.querySelector('video');
                    if (video) {
                        handleVideoSpeed(video, changes.favoriteSpeed.newValue);
                    }
                }
            } catch (error) {
                console.error('Error in storage listener:', error);
            }
        });
    }

    // Initialize the extension
    initializeExtension();

} catch (error) {
    console.error('Extension context invalidated:', error);
    // The extension will be reloaded automatically by the browser
}
